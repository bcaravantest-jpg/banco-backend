package com.umg.backendbanco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendFase1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
