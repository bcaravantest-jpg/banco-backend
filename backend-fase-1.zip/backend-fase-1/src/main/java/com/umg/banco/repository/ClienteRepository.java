package com.umg.banco.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.umg.banco.entity.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

}
